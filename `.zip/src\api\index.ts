// src/api/index.ts
export * from "./inspirations";