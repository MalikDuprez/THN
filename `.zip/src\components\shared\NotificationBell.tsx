// src/components/shared/NotificationBell.tsx
import React, { useEffect, useRef, useState } from "react";
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Text,
  Animated,
} from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useNotificationStore } from "@/stores/notificationStore";

interface NotificationBellProps {
  size?: number;
  color?: string;
  showBadge?: boolean;
  onPress?: () => void;
}

export function NotificationBell({
  size = 24,
  color = "#000",
  showBadge = true,
  onPress,
}: NotificationBellProps) {
  const router = useRouter();
  const { unreadCount, fetchUnreadCount, setupRealtimeSubscription } = useNotificationStore();
  
  // État pour savoir si on affiche le nombre ou juste le point
  const [showNumber, setShowNumber] = useState(true);
  
  // Animation pour la transition
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const widthAnim = useRef(new Animated.Value(1)).current;

  // Charger le compteur au montage
  useEffect(() => {
    fetchUnreadCount();
  }, [fetchUnreadCount]);

  // Abonnement temps réel
  useEffect(() => {
    const unsubscribe = setupRealtimeSubscription();
    return () => unsubscribe();
  }, [setupRealtimeSubscription]);

  // Timer pour passer du nombre au point après 5 secondes
  useEffect(() => {
    if (unreadCount > 0 && showNumber) {
      const timer = setTimeout(() => {
        // Animation de transition
        Animated.sequence([
          // Réduire la taille
          Animated.parallel([
            Animated.timing(scaleAnim, {
              toValue: 0.8,
              duration: 150,
              useNativeDriver: true,
            }),
            Animated.timing(widthAnim, {
              toValue: 0,
              duration: 150,
              useNativeDriver: false,
            }),
          ]),
          // Changer l'état
          Animated.timing(scaleAnim, {
            toValue: 0,
            duration: 50,
            useNativeDriver: true,
          }),
        ]).start(() => {
          setShowNumber(false);
          // Faire apparaître le point
          Animated.spring(scaleAnim, {
            toValue: 1,
            friction: 5,
            tension: 100,
            useNativeDriver: true,
          }).start();
        });
      }, 5000); // 5 secondes

      return () => clearTimeout(timer);
    }
  }, [unreadCount, showNumber]);

  // Réinitialiser quand le compteur change (nouvelle notif)
  useEffect(() => {
    if (unreadCount > 0) {
      setShowNumber(true);
      scaleAnim.setValue(1);
      widthAnim.setValue(1);
    }
  }, [unreadCount]);

  const handlePress = () => {
    if (onPress) {
      onPress();
    } else {
      router.push("/(app)/(shared)/notifications");
    }
  };

  const displayCount = unreadCount > 99 ? "99+" : unreadCount.toString();

  return (
    <TouchableOpacity
      onPress={handlePress}
      style={styles.container}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
    >
      <Ionicons name="notifications-outline" size={size} color={color} />

      {showBadge && unreadCount > 0 && (
        <Animated.View
          style={[
            showNumber ? styles.badgeWithNumber : styles.badgeDot,
            {
              transform: [{ scale: scaleAnim }],
            },
          ]}
        >
          {showNumber && (
            <Text style={styles.badgeText}>{displayCount}</Text>
          )}
        </Animated.View>
      )}
    </TouchableOpacity>
  );
}

// Version pour utilisation dans les tabs (badge séparé)
interface NotificationBadgeProps {
  count: number;
  size?: "small" | "medium";
  animated?: boolean;
}

export function NotificationBadge({
  count,
  size = "medium",
  animated = true,
}: NotificationBadgeProps) {
  const [showNumber, setShowNumber] = useState(true);
  const scaleAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (count > 0 && showNumber && animated) {
      const timer = setTimeout(() => {
        Animated.timing(scaleAnim, {
          toValue: 0,
          duration: 150,
          useNativeDriver: true,
        }).start(() => {
          setShowNumber(false);
          Animated.spring(scaleAnim, {
            toValue: 1,
            friction: 5,
            tension: 100,
            useNativeDriver: true,
          }).start();
        });
      }, 5000);

      return () => clearTimeout(timer);
    }
  }, [count, showNumber, animated]);

  useEffect(() => {
    if (count > 0) {
      setShowNumber(true);
      scaleAnim.setValue(1);
    }
  }, [count]);

  if (count <= 0) return null;

  const isSmall = size === "small";

  return (
    <Animated.View
      style={[
        showNumber
          ? [styles.tabBadgeNumber, isSmall && styles.tabBadgeSmall]
          : [styles.tabBadgeDot, isSmall && styles.tabBadgeDotSmall],
        { transform: [{ scale: scaleAnim }] },
      ]}
    >
      {showNumber && (
        <Text style={[styles.tabBadgeText, isSmall && styles.tabBadgeTextSmall]}>
          {count > 99 ? "99+" : count}
        </Text>
      )}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: "relative",
    padding: 4,
  },
  // Badge avec nombre (sur la cloche)
  badgeWithNumber: {
    position: "absolute",
    top: 0,
    right: 0,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: "#FF3B30",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 5,
    borderWidth: 2,
    borderColor: "#FFF",
  },
  // Point rouge simple (sur la cloche)
  badgeDot: {
    position: "absolute",
    top: 2,
    right: 2,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#FF3B30",
    borderWidth: 2,
    borderColor: "#FFF",
  },
  badgeText: {
    color: "#FFF",
    fontSize: 10,
    fontWeight: "700",
  },
  // Badge pour les tabs - avec nombre
  tabBadgeNumber: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: "#FF3B30",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 6,
  },
  tabBadgeSmall: {
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    paddingHorizontal: 4,
  },
  // Badge pour les tabs - point
  tabBadgeDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#FF3B30",
  },
  tabBadgeDotSmall: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  tabBadgeText: {
    color: "#FFF",
    fontSize: 10,
    fontWeight: "700",
  },
  tabBadgeTextSmall: {
    fontSize: 9,
  },
});

export default NotificationBell;