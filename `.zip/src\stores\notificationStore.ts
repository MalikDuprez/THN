// src/stores/notificationStore.ts
import { create } from "zustand";
import { getUnreadCount, subscribeToNotifications } from "@/api/notifications";
import type { Notification } from "@/types/database";

interface NotificationState {
  unreadCount: number;
  lastNotification: Notification | null;
  isSubscribed: boolean;

  // Actions
  fetchUnreadCount: () => Promise<void>;
  incrementCount: () => void;
  decrementCount: () => void;
  resetCount: () => void;
  setLastNotification: (notification: Notification) => void;
  setupRealtimeSubscription: () => () => void;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  unreadCount: 0,
  lastNotification: null,
  isSubscribed: false,

  fetchUnreadCount: async () => {
    const count = await getUnreadCount();
    set({ unreadCount: count });
  },

  incrementCount: () => {
    set((state) => ({ unreadCount: state.unreadCount + 1 }));
  },

  decrementCount: () => {
    set((state) => ({ unreadCount: Math.max(0, state.unreadCount - 1) }));
  },

  resetCount: () => {
    set({ unreadCount: 0 });
  },

  setLastNotification: (notification: Notification) => {
    set({ lastNotification: notification });
  },

  setupRealtimeSubscription: () => {
    if (get().isSubscribed) {
      return () => {}; // Déjà abonné
    }

    set({ isSubscribed: true });

    const unsubscribe = subscribeToNotifications((notification) => {
      // Nouvelle notification reçue
      set((state) => ({
        unreadCount: state.unreadCount + 1,
        lastNotification: notification,
      }));

      // Ici on pourrait déclencher une notification locale (toast, vibration, etc.)
      console.log("🔔 Nouvelle notification:", notification.title);
    });

    return () => {
      set({ isSubscribed: false });
      unsubscribe();
    };
  },
}));