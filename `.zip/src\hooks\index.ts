// src/hooks/index.ts
// Export hooks globaux ici
