// src/lib/supabase/index.ts
export { supabase } from "./client";
